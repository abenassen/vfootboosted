from django.core.wsgi import get_wsgi_application
import os

import sys
sys.path.append(os.path.abspath("/root/fanta/"))
#sys.path.append(os.path.abspath("./zipbackup/fanta/"))

os.environ['DJANGO_SETTINGS_MODULE'] = 'fanta.settings'
application = get_wsgi_application()


import http.client
import json
import locale
from pytz import timezone
import datetime


from fantaapp.models import *

locale.setlocale(locale.LC_ALL, "it_IT.UTF-8")
tz = timezone('Europe/Rome')




connection = http.client.HTTPConnection('api.football-data.org')
headers = { 'X-Auth-Token': '72d7b2c8c2104a869fc2c2f64d75d6c7'}
connection.request('GET', '/v2/competitions/SA/matches', None, headers )
response = json.loads(connection.getresponse().read().decode())

matches = response['matches']

matchdays = set([mm['matchday'] for mm in matches]) #list of matchdays

matchesg = {g : [m for m in matches if m['matchday'] == g] for g in matchdays} #matches organised in matchdays

teammap = {'AC Milan' : 'Milan', 'ACF Fiorentina': 'Fiorentina', 'AS Roma': 'Roma', 'Atalanta BC' : 'Atalanta', 
           'Bologna FC 1909' : 'Bologna', 'Cagliari Calcio' : "Cagliari", 'Empoli FC': 'Empoli', 
           'FC Internazionale Milano' : 'Inter', 'Genoa CFC' : 'Genoa', 'Hellas Verona FC' : 'Verona', 
           'Juventus FC' : 'Juventus', 'SS Lazio' : 'Lazio', 'SSC Napoli' : 'Napoli', 'Spezia Calcio': 'Spezia',
           'Torino FC' : 'Torino',  'UC Sampdoria' : 'Sampdoria', 'US Salernitana 1919' : 'Salernitana',
           'US Sassuolo Calcio': 'Sassuolo', 'Udinese Calcio':'Udinese', 'Venezia FC': 'Venezia'
          }

startyear = 2022
campionato = Campionato.objects.get(nome="Serie A %d-%d" % (startyear-1, startyear)) # l'oggetto campionato deve essere gia' stato creato
squadre = campionato.squadracampionato_set



for g in matchesg.keys():
    giornata_obj, created = campionato.giornata_set.get_or_create(numero=g)
    print(g)
    for m in matchesg[g]:
        squadra_casa = teammap[m['homeTeam']['name']]
        squadra_trasferta = teammap[m['awayTeam']['name']]
        print(squadra_casa, squadra_trasferta)
        giocato = m['status'] == 'FINISHED'
        dt = datetime.datetime.strptime(m['utcDate'], '%Y-%m-%dT%H:%M:%S%z')
        defaults = {'disputato':giocato, 'data': dt.astimezone}
        if giocato:
            defaults['golcasa'] = matches[0]['score']['fullTime']['homeTeam']
            defaults['goltrasferta'] = matches[0]['score']['fullTime']['awayTeam']
        squadra_casa_obj, created = squadre.get_or_create(nome=squadra_casa)
        squadra_trasferta_obj, created = squadre.get_or_create(nome=squadra_trasferta)
        inc_andata, created = giornata_obj.incontrocampionato_set.update_or_create(squadracasa=squadra_casa_obj, squadratrasferta=squadra_trasferta_obj, defaults=defaults)
    giornata_obj.aggiorna()
