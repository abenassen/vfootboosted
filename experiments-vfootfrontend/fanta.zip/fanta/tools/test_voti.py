import os
import django
import sys
sys.path.append('/root/fanta/')

from tzlocal import get_localzone

uploadtime = 20 # minutes between each upload

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "fanta.settings")
django.setup()


from fantaapp.models import *
from fantaapp.views import *

adesso = datetime.datetime.now(pytz.timezone(settings.TIME_ZONE))


anno = adesso.year
mese = adesso.month
if(mese>=8):
  anno += 1
campionato = Campionato.objects.get(nome=('Serie A %d-%d' % (anno-1, anno)))
giornata = trova_ultima_lega(campionato)

deltat = datetime.timedelta(minutes = 90 + 10 + 30) # 
prima = adesso - deltat
incs = giornata.incontrocampionato_set
for inc in incs.all():
    print(inc, inc.data)
incs = incs.filter(data__gt=prima)
print('numero incontri', len(incs))
if(len(incs) == 0): # tutti gli incontri della giornata corrente sono terminati da un po'; metto il prossimo aggiornamento alla prossima giornata
        numeropross = giornata.numero + 1
        try:
                giornatapross = Giornata.objects.get(campionato = campionato, numero = numeropross)
        except Giornata.DoesNotExist:
                sys.exit() # il campionato e' finito, non faccio piu' nulla
        nuovadata = giornatapross.incontrocampionato_set.earliest('data').data
else:
        nuovadata = incs.earliest('data').data
        nuovadata = max(nuovadata, adesso) # se l'incontro e' in corso faccio l'update subito, altrimenti all'inizio dell'incontro
deltat = datetime.timedelta(minutes = uploadtime)
nuovadata = nuovadata + deltat

#nuovadata = adesso + datetime.timedelta(minutes = 1)


nuovadatalocal = nuovadata.astimezone(get_localzone())
datastr = nuovadatalocal.strftime("%H:%M %d.%m.%Y")


print('data next update:', datastr)

#with open('schedule_aggiornamento_voti.log', mode = 'a') as f:
#    f.write('next update {}\n'.format(datastr))
#stream = os.popen("at {}".format(datastr), mode = 'w')
#stream.write("/root/schedule_voti.sh")
#stream.close()
        
