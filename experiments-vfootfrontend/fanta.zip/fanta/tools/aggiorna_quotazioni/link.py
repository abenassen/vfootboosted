import re
txt = open('quot.html','r').read()
pattern = re.compile("location\.href = \"(https:\/\/www\.fantacalcio\.it\/\/Servizi\/Excel\.ashx\?type=0&r=1&t=[0-9]+)\"")
re.findall(pattern, txt)[0]	
print(re.findall(pattern, txt)[0])
