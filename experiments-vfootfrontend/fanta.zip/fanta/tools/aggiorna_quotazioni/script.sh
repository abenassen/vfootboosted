wget -O quot.html https://www.fantacalcio.it/quotazioni-fantacalcio
source ~/venv/bin/activate
link=$(python link.py)
echo $link
wget -O quot.xlsx $link
ssconvert -O 'separator=";" format=raw' -S quot.xlsx quotdata%s.txt
tail -n +3 quotdataTutti.txt > quotdata.txt
scp quotdata.txt root@139.162.144.123:~/fanta/tools/

