# inserire nuove quotazioni
# dalla shell django
# mettersi nella cartella in cui sta il file completa_quotazioni.py

from completa_quotazioni import *
import datetime
inizio = datetime.datetime(2020, 9, 19) # data inizio del campionato
fine = datetime.datetime(2021, 5, 30)
aggiungi_quotazioni_link_annoprec('Quotazioni/Quotazioni_Fantacalcio_2020-2021.csv', 'Serie A 2020-2021', 'Serie A 2019-2020', 'Napoli', datainizio=inizio, datafine=fine, onlynew=True)

# il file di quotazioni dev'essere della forma seguente
# 2075	C	CRISTOFORO	Fiorentina	1	1	0
