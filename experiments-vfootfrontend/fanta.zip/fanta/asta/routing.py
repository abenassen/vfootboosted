# asta/routing.py
from django.urls import re_path

from . import consumers

websocket_urlpatterns = [
    re_path(r'ws/asta/fanta/lega/(?P<legahash>[a-zA-Z\d]+)/asta/(?P<astaid>[\d]+)/$', consumers.AstaConsumer),
]
