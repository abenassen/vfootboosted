# chat/consumers.py
import json
from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
from asta.views import funzione_aggiornamento


class AstaConsumer(WebsocketConsumer):
    def connect(self):
        self.legahash = self.scope['url_route']['kwargs']['legahash']
        self.astaid = int(self.scope['url_route']['kwargs']['astaid'])
        self.asta_group_name = self.legahash + '_%d' % self.astaid # grouname corresponding to the current asta
        # Join group
        async_to_sync(self.channel_layer.group_add)(
            self.asta_group_name,
            self.channel_name
        )

        self.accept()

    def disconnect(self, close_code):
        # Leave room group
        async_to_sync(self.channel_layer.group_discard)(
            self.asta_group_name,
            self.channel_name
        )

    # Receive message from WebSocket
    def receive(self, text_data):
        if(text_data != 'update'): #check if it is an update message
                return
        #retrieve recent information about asta
        #response_data = json.dumps(funzione_aggiornamento(self.legahash, self.astaid))
        response_data = funzione_aggiornamento(self.legahash, self.astaid)
        print(response_data)
        # Send message to group
        async_to_sync(self.channel_layer.group_send)(
            self.asta_group_name,
            {
                'type': 'update',
                'data': response_data
            }
        )

    # Receive message from room group
    def update(self, event):
        response_data = event['data']
        print("look at this", response_data)
        print(type(response_data))
        # Send message to WebSocket
        self.send(text_data=json.dumps(
            response_data
        ))
